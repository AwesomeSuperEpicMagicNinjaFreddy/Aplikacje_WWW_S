﻿using Microsoft.AspNetCore.Identity;

namespace Kolokwium.Model.DataModels;

public class User : IdentityUser<int>
{

}

