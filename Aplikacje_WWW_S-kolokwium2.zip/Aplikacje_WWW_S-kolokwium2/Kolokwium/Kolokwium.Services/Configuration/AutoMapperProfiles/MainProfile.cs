﻿using AutoMapper;

namespace Kolokwium.Services.Configuration.AutoMapperProfiles;
public class MainProfile : Profile
{
    public MainProfile()
    {
        //AutoMapper maps

    }
}

